import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailad',
  templateUrl: './detailad.component.html',
  styleUrls: ['./detailad.component.css']
})
export class DetailadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
