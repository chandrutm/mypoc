import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailadComponent } from './detailad.component';

describe('DetailadComponent', () => {
  let component: DetailadComponent;
  let fixture: ComponentFixture<DetailadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
