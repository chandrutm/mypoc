import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Ads } from '../_models/ads';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class ListService {

  private createUrl = 'http://localhost:3000/posts';
 constructor(private http: Http) { }

  getAds(){
    return this.http.get(this.createUrl)
      .map(this.extractData)
      .catch(this.handleError);
  }

 


  private extractData(res: Response) {
    let body = res.json();
        return body || {};
  }

  private handleError(error: Response | any) {
    let errMsg: string;
    errMsg = `${error.status} - ${error.statusText || ''} ${error._body}`;
    return Observable.throw(errMsg);
  }



}