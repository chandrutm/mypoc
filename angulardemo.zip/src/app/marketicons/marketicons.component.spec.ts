import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarketiconsComponent } from './marketicons.component';

describe('MarketiconsComponent', () => {
  let component: MarketiconsComponent;
  let fixture: ComponentFixture<MarketiconsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarketiconsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarketiconsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
