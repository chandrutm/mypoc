import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marketicons',
  templateUrl: './marketicons.component.html',
  styleUrls: ['./marketicons.component.css']
})
export class MarketiconsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
