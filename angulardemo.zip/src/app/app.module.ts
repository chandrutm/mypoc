﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule }    from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { fakeBackendProvider } from './_helpers/index';
import { AppComponent }  from './app.component';
import { CarouselComponent } from './carousel/carousel.component';
import { MarketiconsComponent } from './marketicons/marketicons.component';
import { routing }        from './app.routing';
import { AlertComponent } from './_directives/index';
import { AuthGuard } from './_guards/index';
import { JwtInterceptor } from './_helpers/index';
import { AlertService, AuthenticationService, UserService } from './_services/index';
import { HomeComponent } from './home/index';
import { LoginComponent } from './login/index';
import { RegisterComponent } from './register/index';
import { CreateadComponent } from './createad/createad.component';
import { ListadComponent } from './listad/listad.component';
import { DetailadComponent } from './detailad/detailad.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SearchComponent } from './search/search.component';
import { SliderModule } from 'angular-image-slider';
import { ListService } from './_services/list.service';
import { SlideshowModule } from 'ng-simple-slideshow';

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        HttpClientModule,
        HttpModule,
        routing,
        SliderModule,
        SlideshowModule
    ],
    declarations: [
        AppComponent,
        AlertComponent,
        HomeComponent,
        HeaderComponent,
        FooterComponent,
        CarouselComponent,
        MarketiconsComponent,
        SearchComponent,
        LoginComponent,
        RegisterComponent,
        CreateadComponent,
        ListadComponent,
        DetailadComponent
    ],
    providers: [
        AuthGuard,
        AlertService,
        AuthenticationService,
        UserService,
        ListService,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: JwtInterceptor,
            multi: true
        },
        fakeBackendProvider
    ],
    bootstrap: [AppComponent]
})

export class AppModule { }