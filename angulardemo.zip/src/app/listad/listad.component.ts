import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { ListService } from '../_services/list.service';
import { Ads } from '../_models/ads';
@Component({
  selector: 'app-listad',
  templateUrl: './listad.component.html',
  styleUrls: ['./listad.component.css']
})
export class ListadComponent implements OnInit {

ads: Ads[] = [];

  constructor(private listservice: ListService)
   { }

  ngOnInit() {

 this.listservice.getAds().subscribe(ads => {
      this.ads = ads;
      console.log(this.ads);
  });
  
  }

}