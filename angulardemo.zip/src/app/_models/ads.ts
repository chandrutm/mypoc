export class Ads {
    id: number;
    title: string;
    category: string;
}