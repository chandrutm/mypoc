import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createad',
  templateUrl: './createad.component.html',
  styleUrls: ['./createad.component.css']
})
export class CreateadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
