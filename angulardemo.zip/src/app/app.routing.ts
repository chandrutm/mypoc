﻿import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/index';
import { LoginComponent } from './login/index';
import { RegisterComponent } from './register/index';
import { CreateadComponent } from './createad/createad.component';
import { ListadComponent } from './listad/listad.component';
import { DetailadComponent } from './detailad/detailad.component';
import { AuthGuard } from './_guards/index';

const appRoutes: Routes = [
    { path: '', component: HomeComponent},
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },
    { path: 'createad', component: CreateadComponent },
    { path: 'listad', component: ListadComponent },
    { path: 'detaild', component: DetailadComponent },
    { path: '**', redirectTo: '' }
];

export const routing = RouterModule.forRoot(appRoutes);